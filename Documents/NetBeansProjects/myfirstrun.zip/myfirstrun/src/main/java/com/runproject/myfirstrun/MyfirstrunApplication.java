package com.runproject.myfirstrun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyfirstrunApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyfirstrunApplication.class, args);
	}

}
