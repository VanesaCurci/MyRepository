package com.runproject.myfirstrun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyfirstrunApplicationTests {

	@Test
	void contextLoads() {
	}

}
