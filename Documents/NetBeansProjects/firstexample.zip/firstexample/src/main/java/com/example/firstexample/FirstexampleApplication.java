package com.example.firstexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstexampleApplication.class, args);
	}

}
