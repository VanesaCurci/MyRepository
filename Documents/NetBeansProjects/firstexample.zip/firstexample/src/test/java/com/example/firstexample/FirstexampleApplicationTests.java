package com.example.firstexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
