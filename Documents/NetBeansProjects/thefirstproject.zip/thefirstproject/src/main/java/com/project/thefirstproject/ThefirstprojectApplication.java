package com.project.thefirstproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThefirstprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThefirstprojectApplication.class, args);
	}

}
