package com.proyectoportfolio.primerportfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerportfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
