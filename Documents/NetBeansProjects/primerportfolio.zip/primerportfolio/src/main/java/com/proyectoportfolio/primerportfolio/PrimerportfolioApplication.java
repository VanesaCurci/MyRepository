package com.proyectoportfolio.primerportfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimerportfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimerportfolioApplication.class, args);
	}

}
